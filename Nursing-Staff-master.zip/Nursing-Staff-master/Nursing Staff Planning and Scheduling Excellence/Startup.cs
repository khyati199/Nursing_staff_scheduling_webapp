﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Nursing_Staff_Planning_and_Scheduling_Excellence.Startup))]
namespace Nursing_Staff_Planning_and_Scheduling_Excellence
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
