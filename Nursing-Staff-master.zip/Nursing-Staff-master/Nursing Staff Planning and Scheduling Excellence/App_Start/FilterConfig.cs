﻿using System.Web;
using System.Web.Mvc;

namespace Nursing_Staff_Planning_and_Scheduling_Excellence
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
